package com.example.fragmentnew;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.textfield.TextInputEditText;

public class PublishFragment extends Fragment {


    private static final String TAG = PublishFragment.class.getSimpleName();

    private Button send;
    private Button fanOn;
    private Button fanOff;
    private TextInputEditText tl_R;
    private TextInputEditText tl_G;
    private TextInputEditText tl_B;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.publish_fragment, container, false);
        initUi(view);
        return view;
    }
    private void initUi(View view) {
        send = (Button) view.findViewById(R.id.send);
        fanOn = (Button) view.findViewById(R.id.fan_on);
        fanOff = (Button) view.findViewById(R.id.fan_off);
        tl_R = (TextInputEditText) view.findViewById(R.id.R);
        tl_G = (TextInputEditText) view.findViewById(R.id.G);
        tl_B = (TextInputEditText) view.findViewById(R.id.B);


        if(send != null){
            send.setOnClickListener(mOnClickListener);
        }

        if(fanOn != null){
            fanOn.setOnClickListener(mOnClickListener);
        }

        if(fanOff != null){
            fanOff.setOnClickListener(mOnClickListener);
        }

    }

    View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int id = v.getId();
            switch (id){
                case R.id.send:
                    led_send();
                    break;
                case R.id.fan_on:
                    fan(true);
                    break;
                case R.id.fan_off:
                    fan(false);
                    break;
            }
        }
    };

    private void led_send() {
        String R = (tl_R != null) ? tl_R.getText().toString() : "";
        String G = (tl_G != null) ? tl_G.getText().toString() : "";
        String B = (tl_B != null) ? tl_B.getText().toString() : "";

        StringBuilder builder = new StringBuilder();
        builder.append("led");
        builder.append("/");
        builder.append(R);
        builder.append("/");
        builder.append(G);
        builder.append("/");
        builder.append(B);
        ((MainActivity) getActivity()).publishMessage(builder.toString());
    }




    MainActivity.MqttStateListener mMqttStateListener = new MainActivity.MqttStateListener() {
        @Override
        public void connected() {
        }

        @Override
        public void disconnected() {

        }

        @Override
        public void msgArrived(String topic, String msg) {

        }

        @Override
        public void publishSucceed() {

        }

        @Override
        public void publishFailed() {

        }
    };



    @Override
    public void onResume() {
        super.onResume();

        ((MainActivity)getActivity()).registerMqttStateListener(mMqttStateListener);
    }

    @Override
    public void onPause() {
        super.onPause();

        ((MainActivity)getActivity()).unregisterMqttStateListener(mMqttStateListener);
    }

    private void fan(boolean state) {
        if(state) {
            ((MainActivity) getActivity()).publishMessage("f_a/on/f_b/on");
        } else {
            ((MainActivity) getActivity()).publishMessage("f_a/off/f_b/off");
        }
    }

}