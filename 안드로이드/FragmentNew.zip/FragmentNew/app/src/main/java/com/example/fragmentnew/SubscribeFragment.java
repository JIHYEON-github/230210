package com.example.fragmentnew;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SubscribeFragment extends Fragment {
    private static final String TAG = SubscribeFragment.class.getSimpleName();

    public enum Type {
        FAN,
        LED,
        HUMIDITY
    }
    private RecyclerView recyclerView;
    private InfoAdapter infoAdapter;


    MainActivity.MqttStateListener mMqttStateListener = new MainActivity.MqttStateListener() {
        @Override
        public void connected() {}

        @Override
        public void disconnected() {}

        @Override
        public void msgArrived(String topic, String msg) {
//            Log.d(TAG, "Topic" + topic+"msg"+msg);
//            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    String DATE_FORMAT = "HH:mm:ss";
//                    SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
//                    Date date = Calendar.getInstance().getTime();
//                    infoAdapter.addItem(new InfoAdapter.InfoItem(topic, msg, dateFormat.format(date)));
//                    infoAdapter.notifyDataSetChanged();
//
//                }
//            }, 100);


            if (TextUtils.isEmpty(msg)) {
                return;
            }

            String[] buf = msg.split("/");
            if (msg.startsWith("l")) {
                infoAdapter.addItem(new InfoAdapter.InfoItem(Type.LED, buf[1], buf[2], buf[3]));
            } else if (msg.startsWith("f_a")) {
                infoAdapter.addItem(new InfoAdapter.InfoItem(Type.FAN, buf[1], buf[3]));
            } else if (msg.startsWith("h")) {
                infoAdapter.addItem(new InfoAdapter.InfoItem(Type.HUMIDITY, buf[1], buf[3]));
            }
            infoAdapter.notifyDataSetChanged();

        }

        @Override
        public void publishSucceed() {}

        @Override
        public void publishFailed() {}
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.subscribe_fragment, container, false);
        initUi(view);
        return view;
    }


    private void initUi(View view) {
        recyclerView = view.findViewById(R.id.recycler_view);
        infoAdapter = new InfoAdapter();
        LinearLayoutManager layoutManager = new LinearLayoutManager((MainActivity)getActivity(),LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(infoAdapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        ((MainActivity)getActivity()).registerMqttStateListener(mMqttStateListener);
    }

    @Override
    public void onPause() {
        super.onPause();

        ((MainActivity)getActivity()).unregisterMqttStateListener(mMqttStateListener);
    }

}