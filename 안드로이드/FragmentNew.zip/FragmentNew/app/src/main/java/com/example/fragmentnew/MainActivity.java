package com.example.fragmentnew;

import info.mqtt.android.service.Ack;
import info.mqtt.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
//import org.eclipse.paho.client.mqttv3.Exception;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    //Topic 이름 설정, QOS => 보안 관련 레벨
    private static final String PUB_TOPIC = "inTopic5";
    private static final String SUB_TOPIC = "outTopic5";
    private static final int QOS_0=0;

    //mqtt client
    private MqttAndroidClient mqttAndroidClient;

    //Fragment 구성 화면
    private BottomNavigationView bottomNavigationView;
    private FragmentManager fragmentManager;
    private HomeFragment homeFragment;
    private SubscribeFragment subscribeFragment;
    private PublishFragment publishFragment;


    //nested class -> connect의 정보를 이야기한다.
    public static class ConnectInfo {
        String mHost;
        String mPort;
        String mUname;
        String mPw;

        ConnectInfo(String host, String port, String uname, String pw) {
            mHost = host;
            mPort = port;
            mUname = uname;
            mPw = pw;
        }
    }

    //navigation menu 선택시 나오는 화면.
    NavigationBarView.OnItemSelectedListener mOnItemSelectedListener = new NavigationBarView.OnItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            FragmentTransaction ft = fragmentManager.beginTransaction();
            switch (item.getItemId()) {
                case R.id.menu_home:
                    ft.show(homeFragment);
                    ft.hide(subscribeFragment);
                    ft.hide(publishFragment);
                    break;
                case R.id.menu_subscribe:
                    ft.hide(homeFragment);
                    ft.show(subscribeFragment);
                    ft.hide(publishFragment);
                    break;
                case R.id.menu_publish:
                    ft.hide(homeFragment);
                    ft.hide(subscribeFragment);
                    ft.show(publishFragment);
                    break;
            }
            ft.commit();
            return true;
        }
    };

    //nested interface , fragment 클래스들에 인터페이스를 이용해서 뿌려주기 위한것.
    public interface MqttStateListener {
        void connected();
        void disconnected();
        void msgArrived(String topic, String msg);
        void publishSucceed();
        void publishFailed();
    }

    // 인터페이스를 리스트로 받는다? 무슨 뜻이지.
    private List<MqttStateListener> mMqttStateListenerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //
        getSupportActionBar().hide();

        initUi();
    }

    public void initUi(){
        fragmentManager = getSupportFragmentManager();
        homeFragment = new HomeFragment();
        subscribeFragment = new SubscribeFragment();
        publishFragment = new PublishFragment();

        FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.add(R.id.fragment_container, homeFragment);
        ft.add(R.id.fragment_container, subscribeFragment);
        ft.add(R.id.fragment_container, publishFragment);

        ft.show(homeFragment);
        ft.hide(subscribeFragment);
        ft.hide(publishFragment);
        ft.commit();

        bottomNavigationView = findViewById(R.id.bottom_navigation_view);
        bottomNavigationView.setOnItemSelectedListener(mOnItemSelectedListener);

    }

    public void connect(ConnectInfo info) {
        mqttAndroidClient = new MqttAndroidClient(this,  "tcp://" + info.mHost + ":" + info.mPort,
                MqttClient.generateClientId(), Ack.AUTO_ACK);
        mqttAndroidClient.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
                Log.d(TAG, "connectionLost");
                Iterator<MqttStateListener> iterator = getMqttStateListenerList().iterator();
                while(iterator.hasNext()) {
                    MqttStateListener item = iterator.next();
                    if (item != null) {
                        item.disconnected();
                    }
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.d(TAG, "messageArrived");
                Iterator<MqttStateListener> iterator = getMqttStateListenerList().iterator();
                while(iterator.hasNext()) {
                    MqttStateListener item = iterator.next();
                    if (item != null) {
                        item.msgArrived(topic, message.toString());
                    }
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.d(TAG, "deliveryComplete");
            }
        });

        MqttConnectOptions options = new MqttConnectOptions();
        options.setCleanSession(false);
        options.setAutomaticReconnect(true);
        options.setUserName(info.mUname);
        options.setPassword(info.mPw.toCharArray());
        try {
            mqttAndroidClient.connect(options, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.d(TAG, "connect succeed");
                    subscribeTopic();

                    Iterator<MqttStateListener> iterator = getMqttStateListenerList().iterator();
                    while(iterator.hasNext()) {
                        MqttStateListener item = iterator.next();
                        if (item != null) {
                            item.connected();
                        }
                    }
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.d(TAG, "connect failed");
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void publishMessage(String payload) {
        try {
            if (!mqttAndroidClient.isConnected()) {
                mqttAndroidClient.connect();
            }

            MqttMessage message = new MqttMessage();
            message.setPayload(payload.getBytes());
            message.setQos(QOS_0);

            mqttAndroidClient.publish(PUB_TOPIC, message,null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.d(TAG, "publish succeed!");
                    Iterator<MqttStateListener> iterator = getMqttStateListenerList().iterator();
                    while(iterator.hasNext()) {
                        MqttStateListener item = iterator.next();
                        if (item != null) {
                            item.publishSucceed();
                        }
                    }
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.d(TAG, "publish failed!");
                    Iterator<MqttStateListener> iterator = getMqttStateListenerList().iterator();
                    while(iterator.hasNext()) {
                        MqttStateListener item = iterator.next();
                        if (item != null) {
                            item.publishFailed();
                        }
                    }
                }
            });
        } catch (Exception e) {
            Log.e(TAG, e.toString());
            e.printStackTrace();
        }
    }

    private void subscribeTopic() {
        String[] topic = { SUB_TOPIC };
        int[] qos = { QOS_0 };
        try {
            mqttAndroidClient.subscribe(topic, qos, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.d(TAG, "subscribed succeed");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.d(TAG, "subscribed failed");
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private List<MqttStateListener> getMqttStateListenerList() {
        if (mMqttStateListenerList == null) {
            mMqttStateListenerList = new ArrayList<MqttStateListener>();
        }
        return mMqttStateListenerList;
    }

    public void registerMqttStateListener(MqttStateListener listener) {
        try {
            if (!getMqttStateListenerList().contains(listener)) {
                getMqttStateListenerList().add(listener);
            }
        } catch (Exception e) {
        }
    }

    public void unregisterMqttStateListener(MqttStateListener listener) {
        try {
            Iterator<MqttStateListener> iterator = getMqttStateListenerList().iterator();
            while(iterator.hasNext()) {
                MqttStateListener item = iterator.next();
                if (item.equals(listener)) {
                    iterator.remove();
                }
            }
        } catch (Exception e) {
        }
    }


}