package com.example.fragmentnew;

import static android.content.ContentValues.TAG;

import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.textfield.TextInputEditText;


public class HomeFragment extends Fragment {

    private static final String TAG = HomeFragment.class.getSimpleName();

    private TextInputEditText teHost;
    private TextInputEditText tePort;
    private CheckBox cbSsl;
    private Button btnV3;
    private Button btnV5;
    private TextInputEditText teUname;
    private TextInputEditText tePw;
    private Button btnConnect;
    private Button btndisConnect;

    private View clConnected;

    private TextView tvTemperature;
    private TextView tvHumidity;
    private TextView tvFan;
    private TextView tvLed;


    MainActivity.MqttStateListener mMqttStateListener = new MainActivity.MqttStateListener() {
        @Override
        public void connected() {
            updateConnectionState(true);
        }

        @Override
        public void disconnected() {
            Log.d(TAG, "disconnected");
            updateConnectionState(false);
        }

        @Override
        public void msgArrived(String topic, String msg) {

            //null 체크
            if(TextUtils.isEmpty(msg)) {
                return;
            }

            String delimiter = "/";
            String[] buf = msg.split(delimiter);

            if(msg.startsWith("f_a")) {
                tvFan.setText(buf[1]);
            } else if (msg.startsWith("h")) {
                tvHumidity.setText(buf[1]);
                tvTemperature.setText(buf[3]);
            } else if (msg.startsWith("l")) {
                StringBuilder builder = new StringBuilder();
                builder.append("Red: ");
                builder.append(buf[1]);
                builder.append(" Green: ");
                builder.append(buf[2]);
                builder.append(" Blue: ");
                builder.append(buf[3]);

                tvLed.setText(builder.toString());

            }

//            String humidity = buf[1];
//            String temperature = buf[3];
//
//            tvHumidity.setText(humidity);
//            tvTemperature.setText(temperature);
        }

        @Override
        public void publishSucceed() {

        }

        @Override
        public void publishFailed() {

        }
    };



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_fragment, container, false);
        initUI(view);
        return view;
    }

    View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int id = view.getId();
            switch (id) {
                case R.id.connect:
                    connect();
                    break;
                case R.id.disconnect:
                    mMqttStateListener.disconnected();
                case R.id.v3:
                case R.id.v5:
                    versionCheck(id);
                    break;
            }
        }
    };

    private void versionCheck(int id) {
        if(id == R.id.v3){
            btnV3.setBackgroundColor(getResources().getColor(R.color.purple_500));
            btnV3.setTag(true);
            btnV5.setBackgroundColor(Color.GRAY);
        } else if (id == R.id.v5) {
            btnV3.setBackgroundColor(Color.GRAY);
            btnV3.setTag(false);
            btnV5.setBackgroundColor(getResources().getColor(R.color.purple_500));
        }
    }

    private void connect() {
        String host = (teHost != null) ? teHost.getText().toString() : "";
        String port = (tePort != null) ? tePort.getText().toString() : "";
        String uname = (teUname != null) ? teUname.getText().toString() : "";
        String pw = (tePw != null) ? tePw.getText().toString() : "";

        if (TextUtils.isEmpty(host) || TextUtils.isEmpty(port)) {
            return;
        }
        ((MainActivity)getActivity()).connect(new MainActivity.ConnectInfo(host, port, uname, pw));
    }

    public void initUI(View view) {
        teHost = (TextInputEditText) view.findViewById(R.id.host);
        tePort = (TextInputEditText) view.findViewById(R.id.port);
        cbSsl = (CheckBox) view.findViewById(R.id.ssl);
        btnV3 = (Button) view.findViewById(R.id.v3);
        btnV5 = (Button) view.findViewById(R.id.v5);
        teUname = (TextInputEditText) view.findViewById(R.id.username);
        tePw = (TextInputEditText) view.findViewById(R.id.password);
        btnConnect = (Button) view.findViewById(R.id.connect);
        btndisConnect = (Button) view.findViewById(R.id.disconnect);

        tvTemperature = (TextView) view.findViewById(R.id.temperature);
        tvHumidity = (TextView) view.findViewById(R.id.humidity);
        tvFan = (TextView) view.findViewById(R.id.fan);
        tvLed = (TextView) view.findViewById(R.id.led);

        if(btnV3 != null) {
            btnV3.setOnClickListener(mOnClickListener);
        }
        if(btnV5 != null ) {
            btnV5.setOnClickListener(mOnClickListener);
            btnV5.callOnClick();
        }
        if (btnConnect != null) {
            btnConnect.setOnClickListener(mOnClickListener);
        }
        if(btndisConnect != null){
            btndisConnect.setOnClickListener(mOnClickListener);
        }
        clConnected = view.findViewById(R.id.cl_connected);
        clConnected.setOnClickListener(null);
    }

    @Override
    public void onResume() {
        super.onResume();

        ((MainActivity)getActivity()).registerMqttStateListener(mMqttStateListener);
    }

    @Override
    public void onPause() {
        super.onPause();

        ((MainActivity)getActivity()).unregisterMqttStateListener(mMqttStateListener);
    }

    private void updateConnectionState(boolean connection) {
        if (connection) {
            clConnected.setVisibility(View.VISIBLE);
        } else {
            clConnected.setVisibility(View.GONE);
        }
    }


}