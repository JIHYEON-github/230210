package com.example.fragmentnew;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class InfoAdapter extends RecyclerView.Adapter<InfoAdapter.ViewHolder> {
    List<InfoItem> items = new ArrayList<>();

    public static class InfoItem {
//        String topic;
//        String msg;
//        String date;

        SubscribeFragment.Type mType;
        String mFan1;
        String mFan2;
        String mHumidity;
        String mTemperature;
        String mRed;
        String mGreen;
        String mBlue;
        String mTime;

//        public InfoItem(String topic, String msg, String date) {
//            this.topic = topic;
//            this.msg = msg;
//            this.date = date;
//        }

        public InfoItem(SubscribeFragment.Type type, String... param) {
            mType = type;
            if (type == SubscribeFragment.Type.FAN) {
                mFan1 = param[0];
                mFan2 = param[1];
            } else if (type == SubscribeFragment.Type.HUMIDITY) {
                mHumidity = param[0];
                mTemperature = param[1];
            } else if (type == SubscribeFragment.Type.LED) {
                mRed = param[0];
                mGreen = param[1];
                mBlue = param[2];
            }
            mTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        }

//        public String getTopic() { return topic; }
//        public String getMsg() { return msg; }
//        public String getDate() { return date; }

        public String getFan1() { return mFan1; }
        public String getFan2() { return mFan2; }
        public String getHumidity() { return mHumidity; }
        public String getTemperature() { return mTemperature; }
        public String getRed() { return mRed; }
        public String getGreen() { return mGreen; }
        public String getBlue() { return mBlue; }
        public int getIntRed() { return Integer.parseInt(mRed); }
        public int getIntBlue() { return Integer.parseInt(mBlue); }
        public int getIntGreen() { return Integer.parseInt(mGreen); }
        public String getTime() { return mTime; }
    }

//    public class ViewHolder extends RecyclerView.ViewHolder {
//        TextView tvSub;
//        TextView tvDate;
//
//        public ViewHolder(View itemView) {
//            super(itemView);
//
//            tvSub = itemView.findViewById(R.id.subscribe_view);
//            tvDate = itemView.findViewById(R.id.date);
//        }
//
//        public void setItem(InfoItem item) {
//            tvSub.setText(String.format("%s/%s", item.getTopic(), item.getMsg()));
//            tvDate.setText(item.getDate());
//        }
//    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivFan1;
        ImageView ivFan2;
        ImageView ivHumidity;
        ImageView ivTemperature;
        ImageView ivLed;
        ImageView ivColor;
        TextView tvFan1;
        TextView tvFan2;
        TextView tvHumidity;
        TextView tvTemperature;
        TextView tvTimeStamp;

        public ViewHolder(View itemView) {
            super(itemView);

            ivFan1 = itemView.findViewById(R.id.iv_fan1);
            ivFan2 = itemView.findViewById(R.id.iv_fan2);
            ivHumidity = itemView.findViewById(R.id.iv_humidity);
            ivTemperature = itemView.findViewById(R.id.iv_temperature);
            ivLed = itemView.findViewById(R.id.iv_led);
            ivColor = itemView.findViewById(R.id.iv_color);

            tvFan1 = itemView.findViewById(R.id.tv_fan1);
            tvFan2 = itemView.findViewById(R.id.tv_fan2);
            tvHumidity = itemView.findViewById(R.id.tv_humidity);
            tvTemperature = itemView.findViewById(R.id.tv_temperature);
            tvTimeStamp = itemView.findViewById(R.id.tv_timestamp);
        }

        public void setItem(InfoItem item) {
            if (item.mType == SubscribeFragment.Type.FAN) {
                tvFan1.setText(item.getFan1());
                tvFan2.setText(item.getFan2());
            } else if (item.mType == SubscribeFragment.Type.HUMIDITY) {
                tvHumidity.setText(item.getHumidity());
                tvTemperature.setText(item.getTemperature());
            } else if (item.mType == SubscribeFragment.Type.LED) {
                StringBuilder builder = new StringBuilder();
                builder.append("#");
                builder.append(String.format("%02X", item.getIntRed()));
                builder.append(String.format("%02X", item.getIntGreen()));
                builder.append(String.format("%02X", item.getIntBlue()));
                ivColor.setBackgroundColor(Color.parseColor(builder.toString()));
            }

            tvTimeStamp.setText(item.getTime());

            showHideWidget(item.mType);
        }

        private void showHideWidget(SubscribeFragment.Type type) {
            tvFan1.setVisibility(View.GONE);
            tvFan2.setVisibility(View.GONE);
            tvHumidity.setVisibility(View.GONE);
            tvTemperature.setVisibility(View.GONE);

            ivFan1.setVisibility(View.GONE);
            ivFan2.setVisibility(View.GONE);
            ivHumidity.setVisibility(View.GONE);
            ivTemperature.setVisibility(View.GONE);
            ivLed.setVisibility(View.GONE);
            ivColor.setVisibility(View.GONE);

            if (type == SubscribeFragment.Type.FAN) {
                ivFan1.setVisibility(View.VISIBLE);
                ivFan2.setVisibility(View.VISIBLE);
                tvFan1.setVisibility(View.VISIBLE);
                tvFan2.setVisibility(View.VISIBLE);
            } else if (type == SubscribeFragment.Type.HUMIDITY) {
                ivHumidity.setVisibility(View.VISIBLE);
                ivTemperature.setVisibility(View.VISIBLE);
                tvHumidity.setVisibility(View.VISIBLE);
                tvTemperature.setVisibility(View.VISIBLE);
            } else if (type == SubscribeFragment.Type.LED) {
                ivLed.setVisibility(View.VISIBLE);
                ivColor.setVisibility(View.VISIBLE);
            }
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.recyclerview, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InfoItem item = items.get(position);
        holder.setItem(item);
    }

    @Override
    public int getItemCount() { return items.size(); }

    public void addItem(InfoItem item) { items.add(item); }

    public void setItems(ArrayList<InfoItem> items) { this.items = items; }

    public InfoItem getItem(int position) { return items.get(position); }

    public void setItems(int position, InfoItem item) { items.set(position, item); }


}