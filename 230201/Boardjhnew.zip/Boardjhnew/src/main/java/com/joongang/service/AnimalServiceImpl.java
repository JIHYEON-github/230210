package com.joongang.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.joongang.domain.AnimalVO;
import com.joongang.domain.BoardAttachVO;
import com.joongang.mapper.AnimalMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class AnimalServiceImpl implements AnimalService {

	private AnimalMapper mapper;

	@Override
	public List<AnimalVO> getDogList() {
		log.info("get Dog List......");
		return mapper.getDogList();
	}

	@Override
	public List<AnimalVO> getCatList() {
		log.info("get Cat List......");
		return mapper.getCatList();
	}

	@Override
	public void register(AnimalVO animal) {
		log.info("register animal data"+animal);
		mapper.insert(animal);

		/*
		 * if(animal.getAttachList() == null || animal.getAttachList().size() <= 0) {
		 * return; } board.getAttachList().forEach(attach -> {
		 * attach.setBno(board.getBno()); attachMapper.insert(attach); });
		 */
	}

	@Override
	public AnimalVO get(Long animal_no) {
		log.info("get....."+animal_no);
		return mapper.read(animal_no);
	}

	@Override
	public boolean remove(Long animal_no) {
		log.info("remove...."+animal_no);
		
		return mapper.delete(animal_no);
	}



}
