package com.joongang.service;

import java.util.List;

import com.joongang.domain.AnimalVO;
import com.joongang.domain.BoardAttachVO;
import com.joongang.domain.BoardVO;

public interface AnimalService {
	
	public List<AnimalVO> getDogList();
	public List<AnimalVO> getCatList();
	
	
	public void register(AnimalVO animal);
	
	public AnimalVO get(Long animal_no);
	
	public boolean remove(Long animal_no);
	
	
	
}
