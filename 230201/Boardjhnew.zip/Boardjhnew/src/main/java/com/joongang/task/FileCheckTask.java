package com.joongang.task;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.joongang.domain.BoardAttachVO;
import com.joongang.mapper.BoardAttachMapper;

import lombok.extern.log4j.Log4j;

@Log4j
@Component
public class FileCheckTask {
	@Autowired
	private BoardAttachMapper attachMapper;
	
	private String getFolderYesterDay() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1); //어제날짜
		String str = sdf.format(cal.getTime());
		return str.replace("-", File.separator);
	}
	
	@Scheduled(cron = "0 0 2 * * *") //초 분 시 일 월 // 0 0 2 * * * -> 새벽2시마다 
										// 0 1 * * * * -> nn시 1분마다	(1시간에 한번)
										// 1 * * * * * -> nn분 1초마다 (1분에 한번)
	public void checkFiles() throws Exception {
		log.warn("File Check Task run......................");
		log.warn(new Date());
		//file list in database 어제꺼 불러옴
		List<BoardAttachVO> fileList = attachMapper.getOldFiles();
		
		//저장된 파일 리스트 만듦
		//ready for check file in directory with database file list
		List<Path> fileListPaths = fileList.stream()
			.map(vo -> Paths.get("C:\\upload", vo.getUploadPath(), vo.getUuid() + "_" + vo.getFileName()))
			.collect(Collectors.toList());
		
		//썸네일 이미지 리스트 만듦
		//image file has thumbnail file
		fileList.stream().filter(vo -> vo.isFileType() == true)
			.map(vo -> Paths.get("C:\\upload", vo.getUploadPath(), "s_" + vo.getUuid() + "_" + vo.getFileName()))
			.forEach(p -> fileListPaths.add(p));
		
		log.warn("=================================================");
		//저장된 파일리스트 가져와 db에 없는 파일 삭제
		fileListPaths.forEach(p -> log.warn(p));
		//file in yesterday directory
		File targetDir = Paths.get("C:\\upload", getFolderYesterDay()).toFile(); //파일리스트 한개씩 체크
		File[] removeFiles = targetDir.listFiles(file -> fileListPaths.contains(file.toPath()) == false);
		log.warn("-------------------------------------------------");
		if(removeFiles == null) {
			return;
		}
		for (File file : removeFiles) {
			log.warn(file.getAbsolutePath());
			file.delete();
		}
	}
}
