package com.joongang.domain;

import lombok.Data;

@Data
//value object: 가져온 데이터 값들을 저장하는 위치
public class AnimalVO {
	private Long animal_no;
	private String name;
	private String src;
	private String type;
	
	
//	public AnimalVO(String src, String name, AnimalType type) {
//		
//		this.name = name;
//		this.src = src;
//		this.type = type;
//	}
	
	
	public AnimalVO(String src, String name) {
		
		this.name = name;
		this.src = src;
	
	}

}
