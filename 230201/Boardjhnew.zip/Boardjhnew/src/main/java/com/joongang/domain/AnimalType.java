package com.joongang.domain;

public enum AnimalType {
	DOG, CAT
}
