package com.joongang.mapper;

import java.util.List;

import com.joongang.domain.AnimalVO;
import com.joongang.domain.BoardVO;



public interface AnimalMapper {
	public List<AnimalVO> getDogList();
	public List<AnimalVO> getCatList();
	
	public void insert(AnimalVO animal);
	public AnimalVO read(Long animal_no);
	public boolean delete(Long animal_no);
}
