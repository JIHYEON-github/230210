package com.joongang.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.joongang.domain.AnimalVO;
import com.joongang.domain.Criteria;
import com.joongang.service.AnimalService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RequestMapping("/animal/*")
@Controller
@Log4j
@AllArgsConstructor
public class AnimalController {
	
	private AnimalService service;

	@GetMapping("/cats")
	public void cats(Criteria criteria, Model model) { 
		
		/* List<AnimalVO> catList = new ArrayList<>(); */
//		list.add(new AnimalVO("/resources/images/cats/cat1.jpg","아바시니안 분양", AnimalType.CATS));
		/*
		 * catList.add(new AnimalVO("/resources/images/cats/cat1.jpg","아비시니안 분양"));
		 * catList.add(new AnimalVO("/resources/images/cats/cat2.jpg","페르시안 분양"));
		 * catList.add(new AnimalVO("/resources/images/cats/cat3.jpg","샴 분양"));
		 * catList.add(new AnimalVO("/resources/images/cats/cat4.jpg","아메리칸 숏헤어 분양"));
		 */
		model.addAttribute("catList", service.getCatList());
		log.info("Cat list");
		
	}
	
	@GetMapping("/dogs")
	public void dogs(Criteria criteria, Model model) { 
		
		/*
		 * List<AnimalVO> dogList = new ArrayList<>();
		 * 
		 * dogList.add(new AnimalVO("/resources/images/dogs/포메라니안.jpg","포메라니안 분양"));
		 * dogList.add(new AnimalVO("/resources/images/dogs/말티폼.jpg","말티폼 분양"));
		 * dogList.add(new AnimalVO("/resources/images/dogs/비숑프리제.jpg","비숑프리제 분양"));
		 * dogList.add(new AnimalVO("/resources/images/dogs/크림푸들.jpg","크림푸들 분양"))
		 */;
		
		model.addAttribute("dogList", service.getDogList());
		log.info("Dog list");
	}
	
	@GetMapping(value = "/getAttachListOnList", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<Long, AnimalVO>> getAttachListOnList(@RequestParam(value="catList[]") List<Long> catList) {
		
		log.info("getAttachListOnList " + catList.parallelStream().collect(Collectors.toList()));
		Map<Long, AnimalVO> map = new HashMap<Long, AnimalVO>();
		catList.stream().forEach(animal_no->map.put(animal_no, service.get(animal_no)));
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}

