package com.joongang.controller;


import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.joongang.domain.AnimalVO;
import com.joongang.domain.BoardAttachVO;
import com.joongang.service.AnimalService;
import com.joongang.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/admin/*")
@Log4j
@AllArgsConstructor
public class AdminController {
	
	private AnimalService animalService;
	private BoardService service;
	
	@GetMapping("/adminHome")
	public void adminHome() {
		log.info("admin home");
		
	}
	
	@GetMapping("/adminHome/cat")
	public void cat(Model model) {
		model.addAttribute("catList", animalService.getCatList());
	}
	
	@GetMapping("/adminHome/dog")
	public void dog(Model model) {
		model.addAttribute("dogList", animalService.getDogList());
	}
 	
	@GetMapping("/register")
	@PreAuthorize("isAuthenticated()")
	public void register() {
		log.info("admin register...");
	}
	
	@PostMapping("/register")
	@PreAuthorize("isAuthenticated()")
	public String register(AnimalVO animal) {
			
		log.info("register: " + animal.getAnimal_no()+" " +animal.getSrc());
		animalService.register(animal);
		return "redirect:/admin/adminHome"; //redirect: 경로 변경
	}
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/remove")
	public String remove(@RequestParam("animal_no") Long animal_no, RedirectAttributes rttr) {
		log.info("remove....."+animal_no);
		if(animalService.remove(animal_no)) {
			rttr.addFlashAttribute("result","success");
		}
		return "redirect:/admin/adminHome";
	}
	
	

}
