package com.joongang.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.joongang.domain.Criteria;
import com.joongang.service.AnimalService;
import com.joongang.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

/**
 * Handles requests for the application home page.
 */
@Controller
@Log4j
@AllArgsConstructor
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	private AnimalService animalService;
	private BoardService service;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model, Criteria criteria) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		model.addAttribute("catList", animalService.getCatList());
		model.addAttribute("dogList", animalService.getDogList());
		model.addAttribute("list", service.getList(criteria));
		
	
		
		return "home";
	}
	
	
	
	@GetMapping("/signup") 
	public void signup() {
		log.info("signup");
	}

	@GetMapping("/reservation") 
	public void reservation() {
		log.info("reservation");
	}
	
	@GetMapping("/adoption") 
	public void adoption() {
		log.info("adoption");
	}
	@GetMapping("/notice") 
	public void notice() {
		log.info("notice");
	}
	@GetMapping("/location") 
	public void location() {
		log.info("location");
	}
	@GetMapping("/admin") 
	public void admin() {
		log.info("admin");
	}
	
	
}
